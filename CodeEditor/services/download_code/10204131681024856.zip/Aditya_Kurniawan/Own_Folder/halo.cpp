
#include <stdio.h>

int main(){
    int a;
    scanf("%d", &d);
    printf("%d",d);
    
    return 0;
}